import { makeAjaxRequest } from '../../../js/services/ajax.js';
import Navbar from '../../../js/utils/nav.js';
import {displayError} from '../../../js/utils/error-function.js';
import Meeting from '../../../js/models/meetModel.js';

class Calendar
{
    calendar = document.getElementById('date-selector');
    calendarContainer = document.getElementById('calendar-container');

    months = 
    [
        'Jannuary',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
    ];

    days =
    [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'
    ];

    addedMeetings = [];

    setDate = (when) =>
    {
        let longDate = document.getElementById('long-date');
        let daySection = document.getElementById('day-section');
        let myDate;
        if (when === 'Today')
        {
            myDate = new Date();
            this.calendar.value = myDate.getFullYear() + '-' + ('0' + (myDate.getMonth() + 1)).slice(-2) + '-' + ('0' + myDate.getDate()).slice(-2);
        }
        else
            myDate = new Date(this.calendar.value);
        let day = myDate.getDay();
        let dd = myDate.getDate();
        let month = this.months[myDate.getMonth()];
        let year = myDate.getFullYear();
        longDate.innerText = `${dd} ${month} ${year}`
        daySection.innerText = `${this.days[day]}`;
    }

    calcHeight(start,end)
    {
        let unitHeight = 49+3;
        let startMins = (start.hours * 60) + start.minutes;
        let endMins = (end.hours * 60) + end.minutes;
        let totalMinutes = endMins - startMins;
        console.log("total mins ",totalMinutes);
        let finalHeight = (unitHeight * totalMinutes)/60;
        return finalHeight;
    }

    calcMarginTop(start)
    {
        let absoluteMargin = 0;
        let unitHeight = 50+3;
        let factor = start.hours * unitHeight;
        console.log("factor is ",factor);
        let fraction = (start.minutes/60)*unitHeight;
        console.log("fraction is ",fraction);
        factor += fraction
        let margin = absoluteMargin + factor;
        return margin;
    }

    addToCalendar = () =>
    {
        // let parsedMeet = meetings;
        console.log(this.addedMeetings);
        if (this.addedMeetings.length == 0)
        {
            displayError('#calendar-error','* You have no meetings scheduled for today');
            return;
        }
        else
        {
            displayError('#calendar-error','');
        }
        let meet;
        for (meet of this.addedMeetings)
        {
            let attendees = '';
            let _id = meet.meetId;
            // this.addedMeetings.push(_id);
            let meetName = meet.meetName;
            let startTime = meet.start;
            let endTime = meet.end;
            let height = this.calcHeight(startTime,endTime);
            let marginTop = this.calcMarginTop(startTime);
            console.log("final margin top ",marginTop);
            let attendee;
            for (attendee of meet.attendees)
            {
                attendees += `${attendee.email} `;
            }
            let template = 
            `
            <div class="meet-bar-agenda">
                ${meetName}
            </div>
            <div class="meet-bar-attendees">
                Attendees: ${attendees}
            </div>
            `;
            let meetBlock = document.createElement('div');
            meetBlock.className = 'meet-bar';
            meetBlock.id = _id;
            meetBlock.style.top = `${marginTop}px`;
            console.log(meetBlock.style.top);
            meetBlock.style.height = `${height}px`;
            console.log(meetBlock.style.height);
            meetBlock.innerHTML = template;
            this.calendarContainer.appendChild(meetBlock);
        }
    }

    makeMeetingObjects(response, date)
    {
        let meet;
        let meetObject;
        let param;
        for (meet of response)
        {
            param =
            { 
                meetId : meet._id,
                meetName : meet.name,
                date : date,
                start : meet.startTime,
                end : meet.endTime,
                attendees : meet.attendees,
                agenda : meet.description
            };
            meetObject = new Meeting( param );
            this.addedMeetings.push(meetObject);
        }
    }

    fetchCalendar = () =>
    {
        this.flushCalendar();
        let queryDate = this.calendar.value;
       
        makeAjaxRequest({method:'GET', endpoint:`calendar?date=${queryDate}`, body:false, authenticated:true})
            .then(function (response)
            {
                return response.json();
            })
            .then(result => this.makeMeetingObjects(result,queryDate))
            .then(() => this.addToCalendar())
            .catch(error => displayError('#calendar-error',error));
    }

    flushCalendar()
    {
        // addedMeetings is an array of meetings Objects
        let calMeetings;
        for (calMeetings of this.addedMeetings)
        {
            let removed = document.getElementById(calMeetings.meetId);
            this.calendarContainer.removeChild(removed);
        }
        this.addedMeetings = [];
    }

    addEventListeners()
    {
        this.calendar.addEventListener('change',this.setDate);
        this.calendar.addEventListener('change',this.fetchCalendar);
    }
    init()
    {
        this.addEventListeners();
        this.setDate('Today');
        this.fetchCalendar();
    }
}

const myCalendarObj = new Calendar();

myCalendarObj.init();