localStorage.clear();

const emailField = document.getElementById('email-id');
const passField = document.getElementById('password');
const submit = document.getElementById('login-form');

function validateEmail(email) 
{
    const emailReg = new RegExp(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/);
    if( emailReg.test(email) === false ) 
    {
        return false;
    }
    return true;
}

function validatePassword(password)
{
    const passReg = new RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/);
    if( passReg.test(password) === false ) 
    {
        return false;
    }
    return true;
}

function emailTrigger()
{
    let mail = emailField.value;
    if (!validateEmail(mail))
    {
        document.getElementById('login-email-error').innerText = '*Please Enter a Valid Email ID';
        emailField.style.color = "red";
        return false;
    }
    else
    {
        document.getElementById('login-email-error').innerText = "";
        emailField.style.color = "black";
        return true;
    }
}

function passTrigger()
{
    let pass = passField.value;
    if (!validatePassword(pass))
    {
        document.getElementById('login-password-error').innerText = 'Password must contain minimum 8 characters with\n\n\
                                                                    *atleast 1 uppercase\n\
                                                                    *atleast 1 lowercase\n\
                                                                    *atleast 1 digit\n\
                                                                    *atleast 1 Special Character\n';
        passField.style.color = 'red';
        return false;
    }
    else
    {
        document.getElementById('login-password-error').innerText = "";
        passField.style.color = 'black';
        return true;
    }
}

function onError()
{
    let loginError = document.getElementById('login-password-error');
    loginError.innerText = 'Email or Password Incorrect';
    loginError.focus();
}

function onSuccess(message)
{
    let obj = JSON.parse(message);
    let token = obj.token;
    let name = obj.name;
    let email = obj.email;
    localStorage.setItem('token',token);
    localStorage.setItem('email',email);
    localStorage.setItem('name',name);
    window.location.href = 'calendar';
}

emailField.addEventListener('blur',emailTrigger);
passField.addEventListener('blur',passTrigger);

submit.addEventListener('submit',function(event)
{
    event.preventDefault();
    let focusFlag = true;

    if (!emailTrigger())
    {
        if (focusFlag)
        {
            focusFlag = false;
            emailField.focus();
        }
    }
    
    if (!passTrigger())
    {
        // Add inside the outer if 
        if (focusFlag)
        {
            focusFlag = false;
            passField.focus();
        }
    }

    if (focusFlag)
    {
        let xhr = new XMLHttpRequest();
        xhr.addEventListener( 'readystatechange', function() {
            if( xhr.readyState === 4 )
            {
                if( xhr.status == 200 ) 
                {
                    onSuccess( xhr.responseText );
                } 
                
                else if( xhr.status >= 400) 
                {
                    onError( xhr.responseText );
                }
            }  
        });
        let queryString = 'email=' + emailField.value + '&password=' + passField.value;
        console.log(queryString);
        xhr.open('POST', 'https://mymeetingsapp.herokuapp.com/api/auth/login', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.send(queryString);
    }
})