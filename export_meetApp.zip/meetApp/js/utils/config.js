const AppConfig = {
    API_BASE_URL: "https://mymeetingsapp.herokuapp.com/api"
};

export default AppConfig;