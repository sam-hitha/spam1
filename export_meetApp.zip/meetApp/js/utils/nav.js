class Navbar{
    btn = document.getElementById('menu-dropdown');
    menu = document.getElementsByClassName('mobile-menu')[0];
    email = localStorage.getItem('email');
    display = document.getElementsByClassName('display-user-email');
    logoutButtons = document.getElementsByClassName('logout');
    showMenu=()=>{
        
        if (this.menu.style.display == "none")
        {
            this.menu.style.display = "block";
        }
        else
        {
            this.menu.style.display = "none";
        }
    }

    addListeners(){
        this.btn.addEventListener('click',this.showMenu);
    }
    
    setEmail(){
        
        if (this.email !== null)
        {
            this.display[0].innerText = this.email;
            this.display[1].innerText = this.email;
        }
    }



    clearLocalStorage(){
        localStorage.clear();
    }
    
    setLogoutEvent()
    {
        if (this.logoutButtons.length > 0)
        {
            this.logoutButtons[0].addEventListener('click',function(){ 
                this.clearLocalStorage();
            });
            this.logoutButtons[1].addEventListener('click',function(){
                this.clearLocalStorage();
            });
        }
    }


    init(){
        this.addListeners();
        this.setEmail();
        this.setLogoutEvent();
    }

}

const navbar=new Navbar();
navbar.init();

export default Navbar;