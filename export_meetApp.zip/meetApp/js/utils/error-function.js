function displayError(selector, message) {
    document.querySelector(selector).innerText = message; 
}

function displaySuccess(selector,displayMessage) {
    document.querySelector(selector).innerHTML = displayMessage; 
}

export {
    displayError,
    displaySuccess
};



