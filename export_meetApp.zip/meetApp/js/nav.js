function showMenu()
{
    menu = document.getElementsByClassName('mobile-menu')[0];
    if (menu.style.display == "none")
    {
        menu.style.display = "block";
    }
    else
    {
        menu.style.display = "none";
    }
}

function setEmail()
{
    let email = localStorage.getItem('email');
    if (email !== null)
    {
        let email = localStorage.getItem('email');
        let display = document.getElementsByClassName('display-user-email');
        display[0].innerText = email;
        display[1].innerText = email;
    }
}

function setLogoutEvent()
{
    let logoutButtons = document.getElementsByClassName('logout');
    if (logoutButtons.length > 0)
    {
        logoutButtons[0].onclick = function(){
            localStorage.clear();
        }
        logoutButtons[1].onclick = function(){
            localStorage.clear();
        }
    }
}

setEmail();
setLogoutEvent();
