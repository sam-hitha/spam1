(function ()
{
    // Checks for Authentication Token
    if (localStorage.getItem('token') === null)
    {
        window.location.href = 'login';
    }
})();