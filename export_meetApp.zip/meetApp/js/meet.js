const meetName = document.getElementById('meet-name');
const meetDate = document.getElementById('meet-date');
const startTimeH = document.getElementById('start-time-hh');
const startTimeM = document.getElementById('start-time-mm');
const endTimeH = document.getElementById('end-time-hh');
const endTimeM = document.getElementById('end-time-mm');
const meetAgenda = document.getElementById('meet-agenda');
const attendees = document.getElementById('attendees');
const addMeeting = document.getElementById('add-meeting-form');
const token = localStorage.getItem('token');

function validateName(mName)
{
    if (mName === '')
        return false;
    else
        return true;
}

function validateEmail(email) 
{
    const emailReg = new RegExp(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/);
    if( emailReg.test(email) === false ) 
    {
        return false;
    }
    return true;
}

function validateTime(start,end)
{
    startMins = start.hours * 60 + start.minutes;
    endMins = end.hours * 60 + end.minutes;
    totalHours = (endMins - startMins)/60;
    if (totalHours <= 0)
        return false;
    else
        return true;
}

function validateAttendees()
{
    if (attendees.value === '')
    {
        return false;
    }
    let emails = attendees.value.split(',');
    let flag = true;
    for (x of emails)
    {
        flag &= validateEmail(x.trim());
    }
    return flag;
}

function nameTrigger()
{
    let myName = meetName.value;
    if (!validateName(myName))
    {
        document.getElementById('meet-name-error').innerText = '* Meeting name cannot be empty';
        meetName.focus();
        return false;
    }
    else
    {
        document.getElementById('meet-name-error').innerText = '';
        return true;
    }
}

function dateTrigger()
{
    let myDate = meetDate.value;
    if (!validateName(myDate))
    {
        document.getElementById('meet-date-error').innerText = '* Please select a date';
        meetDate.focus();
        meetDate.style.color = 'red';
        return false;
    }
    else
    {
        document.getElementById('meet-date-error').innerText = '';
        meetDate.style.color = 'black';
        return true;
    }
}

function timeTrigger()
{
    let timeError = document.getElementById('end-time-error')
    start = {
        hours:parseInt(startTimeH.value),
        minutes:parseInt(startTimeM.value)
    };

    end = {
        hours:parseInt(endTimeH.value),
        minutes:parseInt(endTimeM.value)
    };
    let res = validateTime(start,end);
    if (!res)
    {
        timeError.innerHTML = '* Start time must be greater than End time';
        startTimeH.focus();
        startTimeH.style.color = 'red';
        startTimeM.style.color = 'red';
        endTimeH.style.color= 'red';
        endTimeM.style.color= 'red';
        return false
    }
    else
    {
        timeError.innerHTML = '';
        startTimeH.style.color = 'black';
        startTimeM.style.color = 'black';
        endTimeH.style.color= 'black';
        endTimeM.style.color= 'black';
        return true;
    }
}

function agendaTrigger()
{
    let res = validateName(meetAgenda.value);
    let errorField = document.getElementById('meet-agenda-error');
    if (!res)
    {
        errorField.innerText = '* Please give a short description';
        meetAgenda.style.color = 'red';
        return false;
    }
    else
    {
        errorField.innerText = '';
        meetAgenda.style.color = 'black';
        return true;
    }
}

function attendeesTrigger()
{
    let errorField = document.getElementById('attendees-error');
    if (!validateAttendees())
    {
        errorField.innerText = '* Please enter valid Email IDs';
        attendees.style.color = 'red';
        return false;
    }
    else
    {
        errorField.innerText = '';
        attendees.style.color = 'black';
        return true;
    }
}

function fetchMembers()
{
    let memberObject = [];
    for (x of attendees.value.split(','))
    {
        memberObject.push({'email':x.trim()});
    }
    return memberObject;
}

function submitMeet(event)
{
    event.preventDefault();
    let focusFlag = true;

    if (!nameTrigger())
    {
        if (focusFlag)
        {
            meetName.focus();
            focusFlag = false;
        }
    }

    if (!dateTrigger())
    {
        if (focusFlag)
        {
            meetDate.focus();
            focusFlag = false;
        }
    }

    if (!timeTrigger())
    {
        if (focusFlag)
        {
            endTimeH.focus();
            focusFlag = false;
        }
    }

    if (!agendaTrigger())
    {
        if (focusFlag)
        {
            meetAgenda.focus();
            focusFlag = false;
        }
    }

    if (!attendeesTrigger())
    {
        if (focusFlag)
        {
            attendees.focus();
            focusFlag = false;
        }
    }

    if (focusFlag)
    {
        var myHeaders = new Headers();
        myHeaders.append("Authorization", token);
        myHeaders.append("Content-Type", "application/json");

        var raw = JSON.stringify({"name":meetName.value,"description":meetAgenda.value,"date":meetDate.value,"startTime":{"hours":parseInt(startTimeH.value),"minutes":parseInt(startTimeM.value)},"endTime":{"hours":parseInt(endTimeH.value),"minutes":parseInt(endTimeM.value)},"attendees":fetchMembers()});

        console.log(raw);

        var requestOptions = 
        {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };

        fetch("https://mymeetingsapp.herokuapp.com/api/meetings", requestOptions)
        .then(response => response.text())
        .then(result => alert('Add Meeting Success!'))
        .catch(error => console.log('Error while adding a meet', error));
    }
}

meetName.addEventListener('blur',nameTrigger);
meetDate.addEventListener('blur',dateTrigger);
endTimeH.addEventListener('change',timeTrigger);
endTimeM.addEventListener('change',timeTrigger);
meetAgenda.addEventListener('blur',agendaTrigger);
attendees.addEventListener('blur',attendeesTrigger);
addMeeting.addEventListener('submit',submitMeet);