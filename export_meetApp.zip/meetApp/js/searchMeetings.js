/* <div class="card">
    <div class="meet-details">
        <span class="meet-search-date">12 September</span> <span class="meet-search-time">06:00 - 07:00</span>
        <div class="meet-agenda">Kick Off</div>
        <button class="excuse">Excuse Yourself</button>
    </div>

    <div class="attendees">
        <span class="search-card-member">Attendees: @example.com, mark@example.com</span>
        <div class="team-select">
            <select name="team-members" >
                <option value="member 1">Member 1</option>
                <option value="member 2">Member 2</option>
                <option value="member 3">Member 3</option>
            </select>
            <button class="add-to-team">Add</button>
        </div>
    </div>
</div> */

const token = localStorage.getItem('token');
const searchForm = document.getElementById('search-meets-form');
const meetDate = document.getElementById('meet-date');
const searchBox = document.getElementById('search-box');
const meetStatus = document.getElementById('meet-search-title');
const cardContainer = document.getElementById('search-results');

const months = 
[
    'Jannuary',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
];

var allMembers;
var allMembersDataList;
let addedMeetings = [];

function makeMemberList(members)
{
    allMembers = JSON.parse(members);
    allMembersDataList = document.createElement('datalist');
    allMembersDataList.id = 'members-list';
    for (x of allMembers)
    {
        let option = document.createElement('option');
        option.value = x.email;
        option.innerText = x.name;
        option.id = x.email;
        allMembersDataList.appendChild(option);
    }
    cardContainer.appendChild(allMembersDataList);
}

function getAllMembers()
{
    console.log('fetch teams called');
    var myHeaders = new Headers();
    myHeaders.append("Authorization", token);

    var requestOptions = 
    {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch("https://mymeetingsapp.herokuapp.com/api/users", requestOptions)
    .then(response => response.text())
    .then(result => makeMemberList(result))
    .catch(error => console.log('error', error));
}

function flushSearchResults()
{
    for (x of addedMeetings)
    {
        let removed = document.getElementById(x);
        try
        {
            cardContainer.removeChild(removed);
        }
        catch
        {
            console.log("Meeting already removed");
        }
    }
    addedMeetings = [];
}

function removeCard(meetID)
{
    let removed = document.getElementById(meetID);
    console.log(removed);
    cardContainer.removeChild(removed);
}

function excuseFromMeet(event)
{
    let meetID = event.target.id.split('-')[1]
    var myHeaders = new Headers();
    myHeaders.append("Authorization", token);

    var requestOptions = 
    {
        method: 'PATCH',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(`https://mymeetingsapp.herokuapp.com/api/meetings/${meetID}?action=remove_attendee`,requestOptions)
    .then(response => response.text())
    .then(result => removeCard(meetID))
    .catch(error => console.log('Failed to Add Member', error));
}

function updateCard(meetID,memberEmail)
{
    if (memberEmail !== '')
    {
        document.getElementById(meetID).membersArray.push(memberEmail);
        let span = document.getElementById(`span-${meetID}`);
        span.innerText += `\n${memberEmail}`;
    }
}

function addMemberToMeet(event)
{
    let meetID = event.target.id.split('-')[1]
    let meetCard = document.getElementById(meetID);
    let memberEmail = document.getElementById("members-" + meetID).value;
    let errorElement = document.getElementById(`error-${meetID}`);

    if (memberEmail === '')
        return;
    console.log(meetCard.membersArray);
    for (x of meetCard.membersArray)
    {
        if (x === memberEmail)
        {
            errorElement.innerText = `* Member ${memberEmail} is already in the meeting`;
            return;
        }
        else
        {
            errorElement.innerText = '';
        }
    }
    var myHeaders = new Headers();
    myHeaders.append("Authorization", token);

    var requestOptions = 
    {
        method: 'PATCH',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(`https://mymeetingsapp.herokuapp.com/api/meetings/${meetID}?action=add_attendee&email=${memberEmail}`,requestOptions)
    .then(response => response.text())
    .then(result => updateCard(meetID,memberEmail))
    .catch(error => console.log('Failed to Add Member', error));
}

function paddedTime(time)
{
    if (time.toString().length == 1)
        return '0' + time;
    else
        return time.toString();
}

function renderMeetCard(meets)
{
    flushSearchResults();
    meetStatus.style.display = 'block';
    if (meets.length <= 0)
    {
        meetStatus.style.color = 'red';
        meetStatus.innerText = 'No Meetings Matched Your Search. Try giving better keywords and remove any special characters';
        return;
    }
    else
    {
        meetStatus.style.color = 'black';
        meetStatus.innerText = 'Meetings Matching Search Criteria';
    }
    for (x of meets)
    {
        let attendeesEmails = [];
        let members = '';
        let _id = x._id;
        addedMeetings.push(_id);
        let meetName = x.name;
        let startH = paddedTime(x.startTime.hours);
        let startM = paddedTime(x.startTime.minutes);
        let endH = paddedTime(x.endTime.hours);
        let endM = paddedTime(x.endTime.minutes);
        let desc = x.description;
        let meetDate = new Date(x.date);
        for (let y = 0; y < x.attendees.length; y++)
        {
            attendeesEmails.push(x.attendees[y].email);
            if (y == x.attendees.length - 1)
                members += (x.attendees[y].email + '\n');
            else
                members += (x.attendees[y].email + ',\n');
        }
        let template = `
        <div class="meet-details">
            <span class="meet-search-date">${meetDate.getDate()} ${months[meetDate.getMonth()]} ${meetDate.getFullYear()}</span> <span class="meet-search-time">${startH}:${startM} - ${endH}:${endM}</span>
            <div class="meet-agenda">${meetName}</div>
            <div class="search-card-member">Description: ${desc}</div>
            <button id=excuse-${_id} class="excuse" onclick="excuseFromMeet(event)">Excuse Yourself</button>
        </div>

        <div class="attendees">
            <span class="search-card-member">Attendees:</span><span id=span-${_id} class="search-card-member"> ${members}</span>
            <div class="team-select">
                <input id=members-${_id} list="members-list" name="team-members">
                <button id=button-${_id} class="add-to-team" onclick="addMemberToMeet(event)">Add</button>
            </div>
            <div id=error-${_id} class="team-form-help"></div>
        </div>
        `
        let card = document.createElement('div');
        card.className = 'card';
        card.id = _id;
        card.membersArray = attendeesEmails;
        card.innerHTML = template;
        cardContainer.appendChild(card);
    }
    
}

function searchMeets(event)
{
    event.preventDefault();
    var myHeaders = new Headers();
    myHeaders.append("Authorization", token);

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };
    let queryString = encodeURI(`https://mymeetingsapp.herokuapp.com/api/meetings?period=${meetDate.value}&search=${searchBox.value}`);
    console.log(queryString);
    fetch(queryString, requestOptions)
    .then(response => response.text())
    .then(result => renderMeetCard(JSON.parse(result)))
    .catch(error => console.log('error', error));
}

window.addEventListener('load',getAllMembers);
searchForm.addEventListener('submit',searchMeets);