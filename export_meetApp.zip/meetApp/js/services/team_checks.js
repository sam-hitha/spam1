import  teamsModule  from '../model/teams_ module.js';
class team_checks 
{
    teamsMod = new teamsModule();
    nameTrigger() 
    {
        let result = (teamName.value === '');
        let nameError = document.getElementById('name-error');
        if (result) 
        {
            nameError.innerText = '* Team Name cannot be blank';
            teamName.style.color = 'red';
            return false;
        }
        else 
        {
            nameError.innerText = '';
            teamName.style.color = 'black';
            return true;
        }
    }

    shortTrigger() 
    {
        let result = (teamShort.value === '');
        let shortError = document.getElementById('team-short-error');
        if (result) 
        {
            shortError.innerText = '* Please specify a team short name';
            teamShort.style.color = 'red';
            return false;
        }
        else 
        {
            shortError.innerText = '';
            teamShort.style.color = 'black';
            return true;
        }
    }

    descTrigger() 
    {
        let result = (teamDesc.value === '');
        let descError = document.getElementById('team-desc-error');
        if (result) 
        {
            descError.innerText = '* Please give a short description of your team';
            teamDesc.style.color = 'red';
            return false;
        }
        else 
        {
            descError.innerText = ''
            teamDesc.style.color = 'black';
            return true;
        }
    }
    showForm() 
    {
        form.style.display = "block";
        button.style.display = "none";
    }

    hideForm() 
    {
        button.style.display = "block";
        form.style.display = "none";
    }
    allListeners() 
    {
        this.button.addEventListener('click', this.showForm);
        this.teamName.addEventListener('change', nameTrigger);
        this.teamShort.addEventListener('change', shortTrigger);
        this.teamDesc.addEventListener('change', descTrigger);

    }

    init() 
    {
        this.allListeners();
    }
}


const teamsChecks = new team_checks();
teamsChecks.init();
export default team_checks;