import AppConfig from '../utils/config.js';

function makeAjaxRequest( {method, endpoint, body, authenticated}  ) 
{
    const headers = new Headers();
    
    const requestOptions = 
    {
        method: method,
        headers: headers,
        redirect: 'follow'
    };

    if( body ) 
    {
        headers.append( 'Content-Type', 'application/json' );
        requestOptions.body = JSON.stringify( body );
    }

    if( authenticated ) 
    {
        headers.append( 'Authorization', localStorage.getItem('token') );
    }

    // sanity check: remove leading slash (if any)
    if( endpoint.substr( 0, 1 ) === '/' ) 
    {
        endpoint = endpoint.substr( 1 );
    }

    return fetch( `${AppConfig.API_BASE_URL}/${endpoint}`, requestOptions )
        .then(response => response);
}

export { makeAjaxRequest };