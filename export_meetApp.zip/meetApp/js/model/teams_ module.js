//import {makeAjaxRequest} from '../services/ajax.js';
import teamPage from '..services/teams.js';
import teamChecks from '..services/team_checks.js';
class teamsModule {
    teams = new teamPage();
    teamCheck = new teamChecks();
    fetchTeams() 
    {
        let myHeaders = new Headers();
        myHeaders.append("Authorization", token);

        let requestOptions =
        {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch("https://mymeetingsapp.herokuapp.com/api/teams", requestOptions)
            .then(response => response.text())
            .then(result => teamPage.renderTeamCards(JSON.parse(result)))
            .catch(error => console.log('error', error));

    }

    submitTeamForm(event) 
    {
        event.preventDefault();
        let focusFlag = true;
        if (!teamCheck.nameTrigger() && focusFlag) 
        {
            focusFlag = false;
            teamName.focus();
        }

        if (!shortTrigger() && focusFlag) 
        {
            focusFlag = false;
            teamShort.focus();
        }

        if (!descTrigger() && focusFlag) 
        {
            focusFlag = false;
            teamDesc.focus();
        }
        // If all fields are valid, makes a POST request to backend
        if (focusFlag) 
        {
            let myHeaders = new Headers();
            myHeaders.append("Authorization", token);
            myHeaders.append("Content-Type", "application/json");

            let raw = JSON.stringify({ "name": teamName.value, "shortName": teamShort.value, "description": teamDesc.value, "members": fetchMembers() });

            let requestOptions =
            {
                method: 'POST',
                headers: myHeaders,
                body: raw,
                redirect: 'follow'
            };

            fetch("https://mymeetingsapp.herokuapp.com/api/teams", requestOptions)
                .then(response => response.text())
                .then(result => teamPage.requestRender(result))
                .catch(error => alert("An error was encountered while adding your team"));
        }
    }
 
    getAllMembers() 
    {
        let myHeaders = new Headers();
        myHeaders.append("Authorization", token);

        let requestOptions =
        {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch("https://mymeetingsapp.herokuapp.com/api/users", requestOptions)
            .then(response => response.text())
            .then(result => teamPage.makeMemberList(result))
            .catch(error => console.log('Error while getting members list', error));

    }
    
    addMemberToTeam(event) 
    {
        let teamID = event.target.id.split('-')[1]
        let teamCard = document.getElementById(teamID);
        let memberEmail = document.getElementById("members-" + teamID).value;
        let errorElement = document.getElementById(`error-${teamID}`);

        if (memberEmail === '')
            return;

        for (email of teamCard.membersArray) 
        {
            if (email === memberEmail) 
            {
                errorElement.innerText = `* Member ${memberEmail} already exists`;
                return;
            }
            else 
            {
                errorElement.innerText = '';
            }
        }
        let myHeaders = new Headers();
        myHeaders.append("Authorization", token);

        let requestOptions =
        {
            method: 'PATCH',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://mymeetingsapp.herokuapp.com/api/teams/${teamID}?action=add_member&email=${memberEmail}`, requestOptions)
            .then(response => response.text())
            .then(teamPage.updateCard(teamID, memberEmail))
            .catch(error => console.log('Failed to Add Member to the Team', error));

    }

    
    excuseFromTeam(event) 
    {
        let teamID = event.target.id.split('-')[1]
        let myHeaders = new Headers();
        myHeaders.append("Authorization", token);

        let requestOptions =
        {
            method: 'PATCH',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://mymeetingsapp.herokuapp.com/api/teams/${teamID}?action=remove_member`, requestOptions)
            .then(response => response.text())
            .then(teamPage.removeCard(teamID))
            .catch(error => console.log('Failed to Add Member', error));

    }
    allEventListeners() 
    {
        this.form.addEventListener('submit', this.submitTeamForm);
        this.window.addEventListener('load', this.getAllMembers);
        this.window.addEventListener('load', this.fetchTeams);
    }
    init() 
    {
        this.allEventListeners();
    }
}
const teamsPage = new teams_module();
teamsPage.init();
export default teamsModule;




