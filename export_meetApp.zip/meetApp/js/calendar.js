const calendar = document.getElementById('date-selector');
const calendarContainer = document.getElementById('calendar-container');
const months = 
[
    'Jannuary',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
];

const days =
[
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday'
];

let addedMeetings = [];

function setDate(when)
{
    let longDate = document.getElementById('long-date');
    let daySection = document.getElementById('day-section');
    let myDate;
    if (when === 'Today')
    {
        myDate = new Date();
        calendar.value = myDate.getFullYear() + '-' + ('0' + (myDate.getMonth() + 1)).slice(-2) + '-' + ('0' + myDate.getDate()).slice(-2);
    }
    else
        myDate = new Date(calendar.value);
    let day = myDate.getDay();
    let dd = myDate.getDate();
    let month = months[myDate.getMonth()];
    let year = myDate.getFullYear();
    longDate.innerText = `${dd} ${month} ${year}`
    daySection.innerText = `${days[day]}`;
}

function calcHeight(start,end)
{
    let unitHeight = 49+3;
    startMins = (start.hours * 60) + start.minutes;
    endMins = (end.hours * 60) + end.minutes;
    totalMinutes = endMins - startMins;
    console.log("total mins ",totalMinutes);
    let finalHeight = (unitHeight * totalMinutes)/60;
    return finalHeight;
}

function calcMarginTop(start)
{
    let absoluteMargin = 0;
    let unitHeight = 50+3; // 49px is the blue bar's height and 4px is the space between bars
    let factor = start.hours * unitHeight;
    console.log("factor is ",factor);
    let fraction = (start.minutes/60)*unitHeight;
    console.log("fraction is ",fraction);
    factor += fraction
    let margin = absoluteMargin + factor;
    return margin;
}

function addToCalendar(meetings)
{
    let parsedMeet = JSON.parse(meetings);
    let calendarError = document.getElementById('calendar-error');
    if (parsedMeet.length == 0)
    {
        calendarError.innerText = '* You have no meetings scheduled for today';
        return;
    }
    else
    {
        calendarError.innerText = '';
    }
    let attendees = '';
    for (x of parsedMeet)
    {
        attendees = '';
        let _id = x._id;
        addedMeetings.push(_id);
        let meetName = x.name;
        let startTime = x.startTime;
        let endTime = x.endTime;
        height = calcHeight(startTime,endTime);
        let marginTop = calcMarginTop(startTime);
        console.log("final margin top ",marginTop);
        for (y of x.attendees)
        {
            attendees += `${y.email} `;
        }
        let template = 
        `
        <div class="meet-bar-agenda">
            ${meetName}
        </div>
        <div class="meet-bar-attendees">
            Attendees: ${attendees}
        </div>
        `;
        let meetBlock = document.createElement('div');
        meetBlock.className = 'meet-bar';
        meetBlock.id = _id;
        meetBlock.style.top = `${marginTop}px`;
        console.log(meetBlock.style.top);
        meetBlock.style.height = `${height}px`;
        console.log(meetBlock.style.height);
        meetBlock.innerHTML = template;
        calendarContainer.appendChild(meetBlock);
    }
}

function fetchCalendar()
{
    flushCalendar();
    let token = localStorage.getItem('token');
    let queryDate = calendar.value;
    console.log(queryDate);
    let myHeaders = new Headers();
    myHeaders.append("Authorization", token);

    let requestOptions = 
    {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(`https://mymeetingsapp.herokuapp.com/api/calendar?date=${queryDate}`, requestOptions)
        .then(response => response.text())
        .then(result => addToCalendar(result))
        .catch(error => console.log('Server Error', error));
}

function flushCalendar()
{
    console.log(addedMeetings.length);
    for (x of addedMeetings)
    {
        let removed = document.getElementById(x);
        calendarContainer.removeChild(removed);
    }
    addedMeetings = [];
}

setDate('Today');
fetchCalendar();
calendar.addEventListener('change',setDate);
calendar.addEventListener('change',fetchCalendar);