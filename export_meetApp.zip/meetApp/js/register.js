const emailField = document.getElementById('email-id');
const passField = document.getElementById('password');
const passConfField = document.getElementById('confirm-password');
const uname = document.getElementById('uname');
const submit = document.getElementById('register-form');


function validateName(uname)
{
    if (uname === '')
        return false;
    else
        return true;
}

function validateEmail(email) 
{
    const emailReg = new RegExp(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/);
    if( emailReg.test(email) === false ) 
    {
        return false;
    }
    return true;
}

function validatePassword(password)
{
    const passReg = new RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/);
    if( passReg.test(password) === false ) 
    {
        return false;
    }
    return true;
}

function confirmPassword(password,confPassword)
{
    if (password == confPassword)
    {
        return true;
    }
    return false;
}

function emailTrigger()
{
    let mail = emailField.value;
    console.log(mail);
    if (!validateEmail(mail))
    {
        document.getElementById('register-email-error').innerText = '*Please Enter a Valid Email ID';
        emailField.style.color = "red";
        return false;
    }
    else
    {
        document.getElementById('register-email-error').innerText = "";
        emailField.style.color = "black";
        return true;
    }
}

function passTrigger()
{
    let pass = passField.value;
    console.log(pass);
    if (!validatePassword(pass))
    {
        document.getElementById('register-pass-error').innerText = 'Password must contain minimum 8 characters with\n\n\
                                                                    *atleast 1 uppercase\n\
                                                                    *atleast 1 lowercase\n\
                                                                    *atleast 1 digit\n\
                                                                    *atleast 1 Special Character\n';
        passField.style.color = 'red';
        return false;
    }
    else
    {
        document.getElementById('register-pass-error').innerText = "";
        passField.style.color = 'black';
        return true;
    }
}

function confPassTrigger()
{
    let pass = passField.value;
    let confPass = passConfField.value;
    console.log(pass);
    if (!confirmPassword(pass,confPass))
    {
        document.getElementById('register-conf-pass-error').innerText = 'Password and confirm password do not match';
        document.getElementById('confirm-password').focus();
        document.getElementById('confirm-password').style.color = 'red';
        return false;
    }
    else
    {
        document.getElementById('register-conf-pass-error').innerText = '';
        document.getElementById('confirm-password').style.color = 'black';
        return true;
    }
}

function nameTrigger()
{
    let myName = uname.value;
    if (!validateName(myName))
    {
        document.getElementById('register-name-error').innerText = '*Name cannot be empty';
        uname.style.color = 'red';
        return false;
    }
    else
    {
        document.getElementById('register-name-error').innerText = '';
        uname.style.color = 'black';
        return true;
    }
}

function onError()
{
    document.getElementById('register-success').innerText = 'User Already Exists';
    document.getElementById('register-success').style.color = 'red';
    document.getElementById('register-success').focus();
}

function onSuccess()
{
    document.getElementById('register-success').innerText = 'Register Success';
    document.getElementById('register-success').style.color = 'green';
    document.getElementById('register-success').focus();
    setTimeout(function(){ window.location.href = "login"; }, 3000);
}

uname.addEventListener('blur',nameTrigger);
emailField.addEventListener('blur',emailTrigger);
passField.addEventListener('blur',passTrigger);
passConfField.addEventListener('blur',confPassTrigger);

submit.addEventListener('submit',function(event)
{
    event.preventDefault();

    let focusFlag = true;
    if (!nameTrigger())
    {
        if (focusFlag)
        {
            focusFlag = false;
            uname.focus();
        }
    }

    if (!emailTrigger())
    {
        if (focusFlag)
        {
            focusFlag = false;
            emailField.focus();
        }
    }
    
    if (!passTrigger())
    {
        if (focusFlag)
        {
            focusFlag = false;
            passField.focus();
        }
    }

    if (!confPassTrigger())
    {
        if (focusFlag)
        {
            focusFlag = false;
            passConfField.focus();
        }
    }

    if (focusFlag)
    {
        let xhr = new XMLHttpRequest();
        xhr.addEventListener( 'readystatechange', function() {
            if( xhr.readyState === 4 )
            {
                if( xhr.status == 204 ) 
                {
                    onSuccess( xhr.responseText );
                } 
                
                else if( xhr.status == 409 ) 
                {
                    onError( xhr.statusText );
                }
            }  
        });
        let queryString = 'name=' + uname.value + '&email=' + emailField.value + '&password=' + passField.value;
        console.log(queryString);
        xhr.open('POST', 'https://mymeetingsapp.herokuapp.com/api/auth/register', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.send(queryString);
    }
})