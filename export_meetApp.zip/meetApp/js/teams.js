/*=====================================Amreeta=============================================*/

const token = localStorage.getItem('token');
const button = document.getElementById('add-team-button');
const form = document.getElementById('teams-register-form');
const teamName = document.getElementById('team-name');
const teamShort = document.getElementById('team-short');
const teamMembers = document.getElementById('team-members');
const teamDesc = document.getElementById('team-description');
const submit = document.getElementById('team-submit');
const cardContainer = document.getElementById('card-container');

function nameTrigger()
{
    /**
     * Triggers the Name validation on the team name of the Team form set to non empty
     */
    let result = (teamName.value === '');
    let nameError = document.getElementById('name-error');
    if (result)
    {
        nameError.innerText = '* Team Name cannot be blank';
        teamName.style.color = 'red';
        return false;
    }
    else
    {
        nameError.innerText = '';
        teamName.style.color = 'black';
        return true;
    }
}

function shortTrigger()
{
    /**
     * Triggers the validation on the team short of the Team form set to non empty
     */
    let result = (teamShort.value === '');
    let shortError = document.getElementById('team-short-error');
    if (result)
    {
        shortError.innerText = '* Please specify a team short name';
        teamShort.style.color = 'red';
        return false;
    }
    else
    {
        shortError.innerText = '';
        teamShort.style.color = 'black';
        return true;
    }
}

function descTrigger()
{
    /**
     * Triggers the Name validation on the team description of the Team form,
     * set to non empty
     */
    let result = (teamDesc.value === '');
    let descError = document.getElementById('team-desc-error');
    if (result)
    {
        descError.innerText = '* Please give a short description of your team';
        teamDesc.style.color = 'red';
        return false;
    }
    else
    {
        descError.innerText = ''
        teamDesc.style.color = 'black';
        return true;
    }
}

function showForm()
{
    /**
     * Function displays the add team form which
     * is initially hidden
     */
    form.style.display = "block";
    button.style.display = "none";
}

function hideForm()
{
    /**
     * Function hides the add team form after
     * successfully adding the team
     */
    button.style.display = "block";
    form.style.display = "none";
}

function fetchMembers()
{
    /**
     * Fetches comma separated Email IDs of the team members
     * from the add team form.
     */
    let memberObject = [];
    for (member of teamMembers.value.split(','))
    {
        memberObject.push({'email':member.trim()});
    }
    return memberObject;
}

function submitTeamForm(event)
{
    /**
     * The function which triggers when the add team form is submitted.
     * This function again runs validation on all the form fields and renders focus
     * on the first element that has an error in validation.
     * Once all fields are validated, the function makes a POST request to the backend to 
     * reflect necessary changes on the backend.
     */
    event.preventDefault();
    let focusFlag = true;
    if (!nameTrigger() && focusFlag)
    {
        focusFlag = false;
        teamName.focus();
    }

    if (!shortTrigger() && focusFlag)
    {
        focusFlag = false;
        teamShort.focus();
    }
    
    if (!descTrigger() && focusFlag)
    {
        focusFlag = false;
        teamDesc.focus();
    }
    // If all fields are valid, makes a POST request to backend
    if (focusFlag)
    {
        let myHeaders = new Headers();
        myHeaders.append("Authorization", token);
        myHeaders.append("Content-Type", "application/json");

        let raw = JSON.stringify({"name":teamName.value,"shortName":teamShort.value,"description":teamDesc.value,"members":fetchMembers()});

        let requestOptions = 
        {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };

        fetch("https://mymeetingsapp.herokuapp.com/api/teams", requestOptions)
        .then(response => response.text())
        .then(result => requestRender(result))
        .catch(error => alert("An error was encountered while adding your team"));
    }
}
/*=========================================Salman===========================================*/

function requestRender(team)
{
    /**
     * A helper function to call the renderTeamCards()
     * and to trigger hideForm() function
     */
    team = JSON.parse(team);
    let tempArray = [];
    tempArray.push(team)
    renderTeamCards(tempArray);
    hideForm();
}

function renderTeamCards(teams)
{
    /**
     * This function accepts a JSON object consisting of all available teams
     * and then renders them into separate cards for each team.
     * This function is called by fetchTeams() and requestRender() function
     */
    for (eachTeam of teams)
    {
        let newTeamCard = document.getElementById('new-team-card');
        let _id = eachTeam._id;
        let teamName = eachTeam.name;
        let shortName = eachTeam.shortName;
        let description = eachTeam.description;
        let membersEmails = [];
        let members = '';
        for (let y = 0; y < eachTeam.members.length; y++)
        {
            membersEmails.push(eachTeam.members[y].email);
            if (y == eachTeam.members.length - 1)
                members += (eachTeam.members[y].email + '\n');
            else
                members += (eachTeam.members[y].email + ',\n');
        }
        let cardTemplate = `
        <div class="team-about">
            <h2>${teamName}</h3>
            <h3>@${shortName}</h3>
            <div class="team-desc">${description}</div>
            <button id=excuse-${_id} class="excuse" onclick="excuseFromTeam(event)">Excuse Yourself</button>
        </div>

        <div class="team-mems">
            <span class="member-head">Members:</span><span id=span-${_id} class="members-span">${members}</span>
            <div class="team-select">
                <input id=members-${_id} list="members-list" name="team-members">
                <button id=button-${_id} class="add-to-team" onclick="addMemberToTeam(event)">Add</button>
            </div>
            <div id=error-${_id} class="team-form-help"></div>
        </div>
        `;
        let card = document.createElement('div');
        card.className = 'card';
        card.id = _id;
        card.membersArray = membersEmails;
        card.innerHTML = cardTemplate;
        cardContainer.insertBefore(card,newTeamCard);
    }
}

function getAllMembers()
{
    /**
     * This function makes a call to the backend to fetch all the 
     * registered members in the raw format and passes it to the 
     * makeMemberList() function to create a datalist.
     * This function executes on load
     */
    let myHeaders = new Headers();
    myHeaders.append("Authorization", token);

    let requestOptions = 
    {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch("https://mymeetingsapp.herokuapp.com/api/users", requestOptions)
    .then(response => response.text())
    .then(result => makeMemberList(result))
    .catch(error=>console.log('Error while getting members list',error));
    // Will be replaced by a toaster box in the next phase
}

function makeMemberList(members)
{
    /**
    * This function accepts a string of all members fetched from the backend
    * and creates a datalist from them which is shared by
    * all team cards 
    * This function is called by getAllMembers() function
    */
    let allMembers = JSON.parse(members);
    let allMembersDataList = document.createElement('datalist');
    allMembersDataList.id = 'members-list';
    for (memberObj of allMembers)
    {
        let option = document.createElement('option');
        option.value = memberObj.email;
        option.innerText = memberObj.name;
        option.id = memberObj.email;
        allMembersDataList.appendChild(option);
    }
    cardContainer.appendChild(allMembersDataList);
}

/*===========================================Samhita=========================================*/

function fetchTeams()
{
    /**
     * This function makes a call to the backend to fetch all the
     * available teams in raw data format. It then calls renderTeamCards()
     * to process the raw data and render it as cards.
     */
    let myHeaders = new Headers();
    myHeaders.append("Authorization", token);

    let requestOptions = 
    {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch("https://mymeetingsapp.herokuapp.com/api/teams", requestOptions)
    .then(response => response.text())
    .then(result => renderTeamCards(JSON.parse(result)))
    .catch(error => console.log('error', error));
    // Will be replaced by a toaster box in the next phase
}

function updateCard(teamID,memberEmail)
{
    /**
     * This function is called by addMemberToTeam() to update the team card
     * with the newly added member. Function accepts team ID and memberEmail
     * to add the email ID ti the respective team's card.
     */
    if (memberEmail !== '')
    {
        document.getElementById(teamID).membersArray.push(memberEmail);
        let span = document.getElementById(`span-${teamID}`);
        span.innerText += `\n${memberEmail}`;
    }
}

function removeCard(teamID)
{
    /**
     * This function is called by excuseFromTeam() to remove the team card
     * from display. Function accepts team ID whose card is to be removed.
     */
    let removed = document.getElementById(teamID);
    cardContainer.removeChild(removed);
}

function addMemberToTeam(event)
{
    /**
     * This function is called when an onclick event to add a member 
     * to a team is triggered. The function accepts the event, fetches
     * team ID from the event target and member email to be added. Using 
     * this information a PATCH request is made to the backed to reflect the changes.
     * The function then makes a call to updateCard() to make necessary changes to the
     * team's card.
     */
    let teamID = event.target.id.split('-')[1]
    let teamCard = document.getElementById(teamID);
    let memberEmail = document.getElementById("members-" + teamID).value;
    let errorElement = document.getElementById(`error-${teamID}`);

    if (memberEmail === '')
        return;
    
    for (email of teamCard.membersArray)
    {
        if (email === memberEmail)
        {
            errorElement.innerText = `* Member ${memberEmail} already exists`;
            return;
        }
        else
        {
            errorElement.innerText = '';
        }
    }
    let myHeaders = new Headers();
    myHeaders.append("Authorization", token);

    let requestOptions = 
    {
        method: 'PATCH',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(`https://mymeetingsapp.herokuapp.com/api/teams/${teamID}?action=add_member&email=${memberEmail}`,requestOptions)
    .then(response => response.text())
    .then(updateCard(teamID,memberEmail))
    .catch(error=>console.log('Failed to Add Member to the Team',error));
    // Will be replaced by a toaster box in the next phase
}

function excuseFromTeam(event)
{
    /**
     * This function is called when an onclick event to excuse yourself from 
     * the meeting is triggered. The function accepts the event, fetches
     * team ID from the event target and member email to be added. Using 
     * this information a PATCH request is made to the backed to reflect the changes.
     * This function further calls removeCard() to remove that particular team card
     * from display.
     */
    let teamID = event.target.id.split('-')[1]
    let myHeaders = new Headers();
    myHeaders.append("Authorization", token);

    let requestOptions = 
    {
        method: 'PATCH',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(`https://mymeetingsapp.herokuapp.com/api/teams/${teamID}?action=remove_member`,requestOptions)
    .then(response => response.text())
    .then(removeCard(teamID))
    .catch(error => console.log('Failed to Add Member', error));
    // Will be replaced by a toaster box in the next phase
}

button.addEventListener('click',showForm);
teamName.addEventListener('blur',nameTrigger);
teamShort.addEventListener('blur',shortTrigger);
teamDesc.addEventListener('blur',descTrigger);
form.addEventListener('submit',submitTeamForm);
window.addEventListener('load',getAllMembers);
window.addEventListener('load',fetchTeams);
