class User{
    constructor( email, password ) {
        this.email = email;
        this.password = password;
    }


    emailReg=new RegExp(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/);
    passReg = new RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/);

    validateEmail() {
        
        const errors=[];
        if (this.emailReg.test(this.email) === false) {
            errors.push( '*Please Enter a Valid Email ID');
        }
        return errors;
    }
    
    validatePassword() {
        
        const errors=[];
        if (this.passReg.test(this.password) === false) {
            errors.push('Password must contain minimum 8 characters with\n\n\
            *atleast 1 uppercase\n\
            *atleast 1 lowercase\n\
            *atleast 1 digit\n\
            *atleast 1 Special Character\n');
        }
        return errors;
    }


    setEmail( email ) {
        this.email = email;
        return this.validateEmail();
    }
    
    setPassword( password ) {
        this.password = password;
        return this.validatePassword();
    }
}

export default User;