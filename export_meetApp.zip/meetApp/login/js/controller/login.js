import { makeAjaxRequest } from '../../../js/services/ajax.js';
import User from '../models/user.js';
import { displayError } from '../../../js/utils/error-function.js';

class Login {

    user = new User( '' , '' )
    emailField = document.getElementById( 'email-id' );
    passField = document.getElementById( 'password' );
    submit = document.getElementById( 'login-form' );
    loginError = document.getElementById( 'login-password-error' );


    clearStorage() 
    {
        localStorage.clear();
    }


    emailTrigger() 
    {

        const errors = this.user.setEmail( this.emailField.value );


        if (errors.length !== 0) 
        {
            displayError('#login-email-error',errors[0])

            this.emailField.style.color = "red";
            return false;
        }
        else 
        {
            displayError('#login-email-error','');
            this.emailField.style.color = "black";
            return true;
        }
    }

    passTrigger() 
    {

        const errors = this.user.setPassword( this.passField.value );

        if (errors.length !== 0) 
        {
            displayError('#login-password-error',errors[0]);
            this.passField.style.color = 'red';

            return false;
        }
        else 
        {
            displayError('#login-password-error','');
            this.passField.style.color = 'black';
            return true;
        }
    }

    onError=()=> 
    {
        this.loginError.innerText = 'Email or Password Incorrect';
        this.loginError.focus();
    }

    onSuccess(message) 
    {
        let obj = message;
        let token = obj.token;
        let name = obj.name;
        let email = obj.email;
        localStorage.setItem( 'token' , token);
        localStorage.setItem( 'email' , email);
        localStorage.setItem( 'name' , name);
        window.location.href = '../calendar/calendar';
    }


    addListeners() {
        this.emailField.addEventListener( 'change' , () =>  this.emailTrigger() );
        this.passField.addEventListener( 'change' , () => this.passTrigger());

        this.submit.addEventListener('submit', (event) => {
            event.preventDefault();
            let focusFlag = true;

            if (( !this.emailTrigger() ) && (focusFlag)) 
            {
                focusFlag = false;
                this.emailField.focus();
            }

            if ((!this.passTrigger()) && (focusflag)) 
            {
                    focusFlag = false;
                    this.passField.focus();
            }

            if (focusFlag) 
            {

                const body = 
                {
                    email: this.emailField.value,
                    password: this.passField.value
                }
                
                makeAjaxRequest( { method:'POST', endpoint:'auth/login', body:body, authenticated:false } )
                    .then( function (response) 
                    {
                        if (response.ok)
                            return response.json();
                        else
                        {
                            const customError = new Error( 'Unable to Login' );
                            customError.errorResponse = error;
                
                            throw customError;
                        }
                    })
                    .then( message => this.onSuccess(message) )
                    .catch(this.onError);
            }
        })

    }
    init() 
    {
        this.clearStorage();
        this.addListeners();
    }


}

const page = new Login();
page.init();

export default Login;
