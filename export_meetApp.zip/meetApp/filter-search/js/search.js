import { makeAjaxRequest } from '../../js/services/ajax.js';

async function getallMembers() {
    return makeAjaxRequest({
        method: 'GET',
        endpoint: `users`,
        authenticated: true
    })
    .then(function (response)
    {
        return response.json();
    });;
}

async function excuseFromMeet(meetID){
    return makeAjaxRequest({
        method: 'PATCH',
        endpoint: `meetings/${meetID}?action=remove_attendee`,
        authenticated: true
    })
    .then(function (response)
    {
        return response.json();
    });;
}
async function addMemberToMeet(meetID,memberEmail){
    return makeAjaxRequest({
        method: 'PATCH',
        endpoint: `meetings/${meetID}?action=add_attendee&email=${memberEmail}`,
        authenticated: true
    })
    .then(function (response)
    {
        return response.json();
    });;
}
async function searchMeets(meetDate,searchBox){
    return makeAjaxRequest({
        method: 'GET',
        endpoint: `meetings?period=${meetDate}&search=${searchBox}`,
        authenticated: true
    })
    .then(function (response)
    {
        return response.json();
    });
}


export {
    excuseFromMeet,
    addMemberToMeet,
    getallMembers,
    searchMeets
};