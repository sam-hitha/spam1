function formatDate(meetDate ) {
    const months = 
[
    'Jannuary',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
];

    return `${meetDate.getDate()} ${months[meetDate.getMonth()]} ${meetDate.getFullYear()}`;
}

export {
    formatDate
};