import { formatDate } from '../Date.js';
import {getallMembers} from '../search.js'
import {excuseFromMeet} from '../search.js';
import {addMemberToMeet} from '../search.js';
import {searchMeets} from '../search.js';
import Navbar from '../../../js/utils/nav.js'
import meet from '../../../addmeeting/js/addmeet-model.js'
import meeting from '../../../addmeeting/js/addmeet-model.js';
class searchMeeting
{

     token = localStorage.getItem('token');
     searchForm = document.getElementById('search-meets-form');

     cardContainer = document.getElementById('search-results');

     allMembers;
     allMembersDataList;
     addedMeetings = [];

    makeMemberList = async() =>
    {
        const members =  await (getallMembers());
        let x;
        this.allMembers = members;
        this.allMembersDataList = document.createElement('datalist');
        this.allMembersDataList.id = 'members-list';
        for (x of this.allMembers)
        {
            //console.log(x);
            let option = document.createElement('option');
            option.value = x.email;
            option.innerText = x.name;
            option.id = x.email;
            this.allMembersDataList.appendChild(option);
        }
        this.cardContainer.appendChild(this.allMembersDataList);
    }

    flushSearchResults()
    {
        let x;
        for (x of this.addedMeetings)
        {
            let removed = document.getElementById(x);
            try
            {
                this.cardContainer.removeChild(removed);
            }
            catch
            {
                console.log("Meeting already removed");
            }
        }
        this.addedMeetings = [];
    }

    removeCard = async() =>
    {
        let meetID = event.target.id.split('-')[1];
        await excuseFromMeet(meetID);
        let removed = document.getElementById(meetID);
        console.log(removed);
        this.cardContainer.removeChild(removed);
    }

    updateCard= async() =>
    {
        let x;
        let meetID = event.target.id.split('-')[1];
        let meetCard = document.getElementById(meetID);
        let memberEmail = document.getElementById("members-" + meetID).value;
        let errorElement = document.getElementById(`error-${meetID}`);

        if (memberEmail === '')
            return;
        for (x of meetCard.membersArray)
        {
            if (x === memberEmail)
            {
                errorElement.innerText = `* Member ${memberEmail} is already in the meeting`;
                return;
            }
            else
            {
                errorElement.innerText = '';
            }
        }
        await addMemberToMeet(meetID,memberEmail);
        if (memberEmail !== '')
        {
            document.getElementById(meetID).membersArray.push(memberEmail);
            let span = document.getElementById(`span-${meetID}`);
            span.innerText += `\n${memberEmail}`;
        }
    }

    paddedTime(time)
    {
        if (time.toString().length == 1)
            return '0' + time;
        else
            return time.toString();
    }

    getMeetings = async(event) =>
    {
        event.preventDefault();
        let x;
        let meetDate = document.getElementById('meet-date').value;
        let searchBox = document.getElementById('search-box').value;
        const meetsRaw = await (searchMeets(meetDate,searchBox));
        const meets = meetsRaw.map(meet => new meeting(meet));
        // const meet = JSON.parse(meets);
        console.log(meets);
        console.log(meetsRaw);
        const meetStatus = document.getElementById('meet-search-title');
        this.flushSearchResults();
        meetStatus.style.display = 'block';
        if (meets.length <= 0)
        {
            meetStatus.style.color = 'red';
            meetStatus.innerText = 'No Meetings Matched Your Search. Try giving better keywords and remove any special characters';
            return;
        }
        else
        {
            meetStatus.style.color = 'black';
            meetStatus.innerText = 'Meetings Matching Search Criteria';
        }
        meets.forEach((meet)=>{
            this.appendMeetsCard(meet);
        })
    }

    appendMeetsCard(meets){
        //const qwer = new addedMeetings(x.name,,'','');
        let attendeesEmails = [];
        let members = '';
        let _id = meets.meetName._id;
        this.addedMeetings.push(_id);
        let meetName = meets.meetName.name;
        let startH = this.paddedTime(meets.meetName.startTime.hours);
        let startM = this.paddedTime(meets.meetName.startTime.minutes);
        let endH = this.paddedTime(meets.meetName.endTime.hours);
        let endM = this.paddedTime(meets.meetName.endTime.minutes);
        let desc = meets.meetName.description;
        let meetDate = new Date(meets.meetName.date);
        for (let y = 0; y < meets.meetName.attendees.length; y++)
        {
            attendeesEmails.push(meets.meetName.attendees[y].email);
            if (y == meets.meetName.attendees.length - 1)
                members += (meets.meetName.attendees[y].email + '\n');
            else
                members += (meets.meetName.attendees[y].email + ',\n');
        }
        let template = `
        <div class="meet-details">
            <span class="meet-search-date">${formatDate(meetDate)}</span> <span class="meet-search-time">${startH}:${startM} - ${endH}:${endM}</span>
            <div class="meet-agenda">${meetName}</div>
            <div class="search-card-member">Description: ${desc}</div>
            <button id=excuse-${_id} class="excuse">Excuse Yourself</button>
        </div>

        <div class="attendees">
            <span class="search-card-member">Attendees:</span><span id=span-${_id} class="search-card-member"> ${members}</span>
            <div class="team-select">
                <input id=members-${_id} list="members-list" name="team-members">
                <button id=button-${_id} class="add-to-team">Add</button>
            </div>
            <div id=error-${_id} class="team-form-help"></div>
        </div>
        `
        let card = document.createElement('div');
        card.className = 'card';
        card.id = _id;
        card.membersArray = attendeesEmails;
        card.innerHTML = template;
        this.cardContainer.appendChild(card);
        document.querySelectorAll('.add-to-team').forEach((button)=>{
            button.addEventListener('click',this.updateCard);
        });
        document.querySelectorAll('.excuse').forEach((button)=>{
            button.addEventListener('click',this.removeCard);
        });
    }

    addListeners() {
        window.addEventListener('load',this.makeMemberList);
        
    }


    init() {

        try {
            // IMPORTANT: It is ok to call addListeners before data fetch on this page, as the only element on which the click handler is set is the hide details button, which is available in the HTML even BEFORE data is fetched and workshop list item cards are shown.
            document.querySelector( '#search-meets-form' ).addEventListener( 'submit', this.getMeetings );
            this.addListeners();
        } catch( err ) {
            console.log(err.message);
        }
    }
}

const page = new searchMeeting();
page.init();
