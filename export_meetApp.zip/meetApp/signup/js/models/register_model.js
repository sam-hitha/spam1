
console.log("we are in model..")
class RegisterModel {

    constructor( email, password, confirmPassword, uname ) {
        this.email = email;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.uname = uname;
    }

    validateName = (uname) => {
        console.log(uname,"------uname")
        if (uname === '')
            return false;
        else
            return true;
    }

    validateEmail = (email) => {
        console.log(email,"------email")
        const emailReg = new RegExp(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/);
        if( emailReg.test(email) === false ){
            return false;
        }
        return true;
    }

    validatePassword = (password) => {
        console.log(password,"------password")
        const passReg = new RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/);
        if( passReg.test(password) === false ){
            return false;
        }
        return true;
    }

    check = (password,confPassword) => {
        console.log("i am in required model");
        if(password == confPassword){
            return true;
        }
        return false;
    }
}

export default RegisterModel;