console.log("we are in controller");
import RegisterModel from '../models/register_model.js';
import { makeAjaxRequest } from '../../../js/services/ajax.js';
class RegisterPage {

    emailField = document.getElementById('email-id');
    passField = document.getElementById('password');
    passConfField = document.getElementById('confirm-password');
    uname = document.getElementById('uname');
    submit = document.getElementById('register-form');
    htmlData = document.getElementById('register-success');

    newRegisterationModel = new RegisterModel( '', '', '', '' );

    emailTrigger = () => 
    {
        let mail = this.emailField.value;
        console.log(mail);
        if (!this.newRegisterationModel.validateEmail(mail)) {
            document.getElementById('register-email-error').innerText = '*Please Enter a Valid Email ID';
            this.emailField.style.color = "red";
            return false;
        }
        else {
            document.getElementById('register-email-error').innerText = "";
            this.emailField.style.color = "black";
            return true;
        }
    }

    passTrigger = () => {
        let pass = this.passField.value;
        console.log(pass);
        if (!this.newRegisterationModel.validatePassword(pass)) {
            document.getElementById('register-pass-error').innerText = 'Password must contain minimum 8 characters with\n\n\
                                                                        *atleast 1 uppercase\n\
                                                                        *atleast 1 lowercase\n\
                                                                        *atleast 1 digit\n\
                                                                        *atleast 1 Special Character\n';
            this.passField.style.color = 'red';
            return false;
        }
        else {
            document.getElementById('register-pass-error').innerText = "";
            this.passField.style.color = 'black';
            return true;
        }
    }

    confPassTrigger = () => {
        let pass = this.passField.value;
        let confPass = this.passConfField.value;
        console.log(pass,"this is bteakpoint ");
        if (!this.newRegisterationModel.check(pass,confPass)) {
            console.log(pass,"this is bteakpoint inside  ");
            document.getElementById('register-conf-pass-error').innerText = 'Password and confirm password do not match';
            document.getElementById('confirm-password').focus();
            document.getElementById('confirm-password').style.color = 'red';
            return false;
        }
        else { 
            console.log(pass,"this is bteakpoint else ");
            document.getElementById('register-conf-pass-error').innerText = '';
            document.getElementById('confirm-password').style.color = 'black';
            return true;
        }
    }

    nameTrigger = () => {
        let myName = uname.value;
        if (!this.newRegisterationModel.validateName(myName)) {
            document.getElementById('register-name-error').innerText = '*Name cannot be empty';
            uname.style.color = 'red';
            return false;
        }
        else {
            document.getElementById('register-name-error').innerText = '';
            uname.style.color = 'black';
            return true;
        }
    }


    onError = () => {
        console.log('OnError function called' );
        this.htmlData.innerText = 'User Already Exists';
        this.htmlData.style.color = 'red';
        this.htmlData.focus();
    }

    onSuccess = () => {
        console.log("On success called");
        this.htmlData.innerText = 'Register Success';
        this.htmlData.style.color = 'green';
        this.htmlData.focus();
       // setTimeout(function(){ window.location.href = "login"; }, 3000);
    }

    onFormsubmitTrigger = (event) => {
        event.preventDefault();
        let focusFlag = true;
        if (!this.nameTrigger() && focusFlag) 
        {
            focusFlag = false;
            uname.focus();
        }
        if (!this.emailTrigger()) {
            if (focusFlag) {
                focusFlag = false;
                emailField.focus();
            }
        }
        if (!this.passTrigger()) {
            if (focusFlag) {
                focusFlag = false;
                passField.focus();
            }
        }
        if (!this.confPassTrigger()) {
            if (focusFlag) {
                focusFlag = false;
                passConfField.focus();
            }
        }
        if (focusFlag) {
            //let xhr = new XMLHttpRequest();
            const body = {
                name : this.uname.value,
                email : this.emailField.value,
                password : this.passField.value
            }

            console.log(body,"---body")

            makeAjaxRequest({ method : 'POST', endpoint: "auth/register", body:body ,authenticated : false} )
            // .then(function(response){
            //     console.log(response,"response")
            //     return response
            // })
            .then(response =>
            {
                if (response.ok)
                    this.onSuccess();
                else
                    this.onError();
            })
            .catch(error => console.log(error));

            // xhr.addEventListener( 'readystatechange', () => {
            //     if( xhr.readyState === 4 ){
            //         if( xhr.status == 204 ) {
            //             this.onSuccess( xhr.responseText );
            //         } 
                    
            //         else if( xhr.status == 409 ) {
            //             this.onError( xhr.statusText );
            //         }
            //     }  
            // });
            // let queryString = 'name=' + this.uname.value + '&email=' + this.emailField.value + '&password=' + this.passField.value;
            // console.log(queryString);
            // xhr.open('POST', 'https://mymeetingsapp.herokuapp.com/api/auth/register', true);
            // xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            // xhr.send(queryString);
        }
    }

    addListeners() {
        this.uname.addEventListener('input',this.nameTrigger);
        this.emailField.addEventListener('input',this.emailTrigger);
        this.passField.addEventListener('input',this.passTrigger);
        this.passConfField.addEventListener('input',this.confPassTrigger);
        this.submit.addEventListener('submit',this.onFormsubmitTrigger);    
    }

    init() {
        this.addListeners();
    }
}

 
const regPage = new RegisterPage(); 
regPage.init();

export default RegisterPage;