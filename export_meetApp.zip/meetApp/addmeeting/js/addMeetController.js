//Importing the required functions/classes
import { makeAjaxRequest } from '../../js/services/ajax.js';
import Meeting from '../../js/models/meetModel.js';
import { displayError,displaySuccess} from '../../js/utils/error-function.js';
import Navbar from '../../../js/utils/nav.js';
import {checkAuth} from '../../js/utils/checkAuth.js';


class addMeet 
{

    meetings = new Meeting('','', '', '', '', '','');
    meetName = document.getElementById('meet-name');
    meetDate = document.getElementById('meet-date');
    startTimeH = document.getElementById('start-time-hh');
    startTimeM = document.getElementById('start-time-mm');
    endTimeH = document.getElementById('end-time-hh');
    endTimeM = document.getElementById('end-time-mm');
    meetAgenda = document.getElementById('meet-agenda');
    attendees = document.getElementById('attendees');
    addMeeting = document.getElementById('add-meeting-form');

   
    //Triggers the 'Validate Name' function that returns false if the input field is empty - respective error function is hence called
    nameTrigger() 
    {
        this.meetings.meetName = this.meetName.value;

        if (!this.meetings.validateName())
        {
            displayError('#meet-name-error', '*Meeting Name cannot be empty');
            this.meetName.style.color = 'red';
            return false;
        }
        else
        {
            displayError('#meet-name-error', '');
            this.meetName.style.color = 'black';
            return true;
        }
    }

    dateTrigger()
    { 
        this.meetings.date = this.meetDate.value;
        if (!this.meetings.validateDate())
        {
            displayError('#meet-date-error', '* Please select a date');
            this.meetDate.style.color = 'red';
            return false;
        }
        else
        {
            displayError('#meet-date-error', '');
            this.meetDate.style.color = 'black';
            return true;
        }
    }

    //Triggers the 'Validate Time' function that returns false if the start time is less than end time
    timeTrigger()
    { 
        this.meetings.start = 
        {
            hours: parseInt(this.startTimeH.value),
            minutes: parseInt(this.startTimeM.value)
        };

        this.meetings.end = 
        {
            hours: parseInt(this.endTimeH.value),
            minutes: parseInt(this.endTimeM.value)
        };

        const res = this.meetings.validateTime();
        if (!res) 
        {
            displayError('#end-time-error', '* Start time must be greater than End time');
            this.startTimeH.style.color = 'red';
            this.startTimeM.style.color = 'red';
            this.endTimeH.style.color = 'red';
            this.endTimeM.style.color = 'red';
            return false
        }
        else
        {
            displayError('#end-time-error', '');
            this.startTimeH.style.color = 'black';
            this.startTimeM.style.color = 'black';
            this.endTimeH.style.color = 'black';
            this.endTimeM.style.color = 'black';
            return true;
        }
    }

    agendaTrigger()
    { 
        this.meetings.agenda = this.meetAgenda.value;
       
        if (!this.meetings.validateAgenda())
        {
            displayError('#meet-agenda-error', '*Please give a short description');
            this.meetAgenda.style.color = 'red';
            return false;
        }
        else
        {
            displayError('#meet-agenda-error', '');
            this.meetAgenda.style.color = 'black';
            return true;
        }
    }

    
    //Triggers 'Validate Attendees' to ensure non empty input and to also ensure that email entered is in the required format
    attendeesTrigger()
    {
        this.meetings.attendees = this.fetchMembers();
        if (!this.meetings.validateAttendees())
        {
            displayError('#attendees-error', '* Please enter valid Email IDs');
            this.attendees.style.color = 'red';
            return false;
        }
        else
        {
            displayError('#attendees-error', '');

            this.attendees.style.color = 'black';
            return true;
        }
    }

    fetchMembers()
    {
        let memberObject = [];
        let x;
        for (x of this.attendees.value.split(','))
        {
            memberObject.push({ 'email': x.trim() });
        }
        return memberObject;
    }

    addListeners()
     {
        this.meetName.addEventListener('change', () => this.nameTrigger());
        this.meetDate.addEventListener('change', () => this.dateTrigger());
        this.endTimeH.addEventListener('change', () => this.timeTrigger());
        this.endTimeM.addEventListener('change', () => this.timeTrigger());
        this.meetAgenda.addEventListener('change', () => this.agendaTrigger());
        this.attendees.addEventListener('change', () => this.attendeesTrigger());

            /**
         * The function triggers when the 'Add Meeting' form is submitted.
         * This function again runs validation on all the form fields and renders focus
         * on the first element that has an error in validation.
         * Once all fields are validated, the function makes a POST request to 
         * reflect necessary changes (i.e, add a new meeting) to the backend.
         */
        this.addMeeting.addEventListener('submit', (event) => 
        {
            event.preventDefault();
            let focusFlag = true;


            if (!this.nameTrigger() && focusFlag)
            {
                console.log("name");
                this.meetName.focus();
                focusFlag = false;
            }


            if (!this.dateTrigger() && focusFlag)
            {
                console.log("date");
                this.meetDate.focus();
                focusFlag = false;
            }


            if (!this.timeTrigger() && focusFlag)
            {
                console.log("time");
                this.endTimeH.focus();
                focusFlag = false;
            }

            if (!this.agendaTrigger() && focusFlag)
            {
                console.log("agenda");
                this.meetAgenda.focus();
                focusFlag = false;
            }

            if (!this.attendeesTrigger() && focusFlag)
            {
                console.log("attendees");
                this.attendees.focus();
                focusFlag = false;
            }


            if (focusFlag)
            {
                const body = 
                {
                    "name": this.meetings.meetName,
                    "description": this.meetings.agenda,
                    "date": this.meetings.date,
                    "startTime": { "hours": this.meetings.start.hours, "minutes": this.meetings.start.minutes },
                    "endTime": { "hours": this.meetings.end.hours, "minutes": this.meetings.end.minutes },
                    "attendees": this.meetings.attendees
                }

                makeAjaxRequest({ method: 'POST', endpoint: 'meetings', body: body, authenticated: true })
                    .then(response => response.text())
                    .then(function (response) {
                        console.log(response)
                        return response
                    })
                    .then(result => displaySuccess('#meeting-success-message' ,'Meeting has been added Successfully !'))
                    .then(result => alert('Add Meeting Success!'))
                    .catch(error => console.log('Error while adding a meet', error));
            }
        })
    }

    init() 
    {
        this.addListeners();
    }
}

const page = new addMeet();
page.init();
