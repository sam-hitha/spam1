class meeting 
{
    constructor(meetName, date, start, end, attendees, agenda) 
    {
        this.meetName = meetName;
        this.date = date;
        this.start = start;
        this.end = end;
        this.attendees = attendees;
        this.agenda = agenda;
    }

    emailReg = new RegExp(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/);

    validateName() 
    {
        console.log(this.meetName);
        if (this.meetName === '')
            return false;
        else
            return true;
    }

    validateDate() 
    {
        if (this.date === '')
            return false;
        else
            return true;
    }

    validateAgenda() 
    {
        if (this.agenda === '')
            return false;
        else
            return true;
    }

    validateEmail(email)
    {

        if (this.emailReg.test(email) === false)
        {
            return false;
        }
        return true;
    }

    validateTime()
    {
        let startMins = this.start.hours * 60 + this.start.minutes;
        let endMins = this.end.hours * 60 + this.end.minutes;
        let totalHours = (endMins - startMins) / 60;
        if (totalHours <= 0)
            return false;
        else
            return true;
    }



    validateAttendees()
    {
        console.log(this.attendees);
        if (this.attendees === '')
        {
            return false;
        }
        // let emails = this.attendees.split(',');
        let flag = true;
        let x;
        for (x of this.attendees)
        {
            console.log(x.email);
            flag &= this.validateEmail(x.email);
        }
        return flag;
    }
}

export default meeting;
