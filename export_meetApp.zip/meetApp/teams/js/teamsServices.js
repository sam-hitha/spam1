import { makeAjaxRequest } from '../../js/services/ajax.js';

async function getallMembers() {
    return makeAjaxRequest({
        method: 'GET',
        endpoint: `teams`,
        authenticated: true
    })
    .then(function (response)
    {
        return response.json();
    });;
}

async function excuseFromTeam(teamID){
    return makeAjaxRequest({
        method: 'PATCH',
        endpoint: `teams/${teamID}?action=remove_member`,
        authenticated: true
    })
    .then(function (response)
    {
        return response.json();
    });;
}

async function addMemberToTeam(teamID,memberEmail){
    return makeAjaxRequest({
        method: 'PATCH',
        endpoint: `teams/${teamID}?action=add_member&email=${memberEmail}`,
        authenticated: true
    })
    .then(function (response)
    {
        return response.json();
    });;
}
async function fetchTeams(){
    return makeAjaxRequest({ 
      method: 'GET', 
      endpoint: 'teams', 
      authenticated: true 
    })
    .then(function (response)
    {
        return response.json();
    });;
}

export {
    excuseFromTeam,
    addMemberToTeam,
    getallMembers,
    fetchTeams
};