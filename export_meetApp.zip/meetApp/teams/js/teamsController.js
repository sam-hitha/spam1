import { makeAjaxRequest } from '../../js/services/ajax.js';
import team from './teamsModel.js';
import { displayError } from '../../js/utils/error-function.js';
import team from '../js/teams-mod.js';
import Navbar from '../../../js/utils/nav.js';
class Addteam {
    teams = new team('', '', '', '');
    button = document.getElementById('add-team-button');
    form = document.getElementById('teams-register-form');
    teamName = document.getElementById('team-name');
    teamShort = document.getElementById('team-short');
    teamMembers = document.getElementById('team-members');
    teamDesc = document.getElementById('team-description');
    submit = document.getElementById('team-submit');
    cardContainer = document.getElementById('card-container');

    nameTrigger() {
        this.teams.teamName = (this.teamName.value === '');
        if (this.teams.teamName) {
            displayError('#name-error', '*Team Name cannot be empty');
            this.teamName.style.color = 'red';
            return false;
        }
        else {
            displayError('name-error', '');
            this.teamName.style.color = 'black';
            return true;
        }
    }
    shortTrigger() {
        this.teams.teamShort = (this.teamShort.value === '');
        if (this.teams.teamShort) {
            displayError('#team-short-error', '*Please specify a team short name');
            this.teamShort.style.color = 'red';
            return false;
        }
        else {
            displayError('#team-short-error', '');
            this.teamShort.style.color = 'black';
            return true;
        }
    }
    descTrigger() {
        this.teams.teamDesc = (this.teamDesc.value === '');
        if (this.teams.teamDesc) {
            displayError('#team-desc-error', '*Please give a short description of your team');
            this.teamDesc.style.color = 'red';
            return false;
        }
        else {
            displayError('#team-desc-error', '');
            this.teamDesc.style.color = 'black';
            return true;
        }
    }

    fetchMembers() {

        let memberObject = [];
        for (member of teamMembers.value.split(',')) {
            memberObject.push({ 'email': member.trim() });
        }
        return memberObject;
    }
    showForm() {

        this.form.style.display = "block";
        this.button.style.display = "none";
    }

    hideForm() {

        this.button.style.display = "block";
        this.form.style.display = "none";
    }


    addListeners() {
        this.teamName.addEventListener('change', () => this.nameTrigger());
        this.teamShort.addEventListener('change', () => this.shortTrigger());
        this.teamDesc.addEventListener('change', () => this.descTrigger());
        this.button.addEventListener('click',() => this.showForm());

        this.form.addEventListener('submit', (event) => {
            event.preventDefault();
            let focusFlag = true;
            if (!nameTrigger() && focusFlag) {
                focusFlag = false;
                teamName.focus();
            }

            if (!shortTrigger() && focusFlag) {
                focusFlag = false;
                teamShort.focus();
            }

            if (!descTrigger() && focusFlag) {
                focusFlag = false;
                teamDesc.focus();
            }
            if (focusFlag) {
                const body = {
                    name: this.teams.teamName,
                    shortName: this.teams.teamShort,
                    description: this.teams.teamDesc,
                    members: this.teams.teamMembers
                }

                makeAjaxRequest({ method: 'POST', endpoint: 'teams', body: body, authenticated: true })
                    .then(response => response.text())
                    .then(function (response) {
                        console.log(response)
                        return response
                    })
                    .then(result => alert('Add Team Success!'))
                    .catch(error => console.log('Error while adding a team', error));
            }

        })


    }
    init() {
        this.addListeners();
    }
}
const page = new Addteam();
page.init();
