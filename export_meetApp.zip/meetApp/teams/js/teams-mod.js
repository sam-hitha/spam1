import {getallMembers} from '../teamsServices.js'
import {excuseFromTeam} from '../teamsServices.js';
import {addMemberToTeam} from '../teamsServices.js';
import {fetchTeams} from '../teamsServices.js';
import Addteam from '../teamsController.js';
import Navbar from '../../../js/utils/nav.js'
import { displayError } from '../../js/utils/error-function.js';
class team {
    addTeam=new Addteam();
    constructor(teamName, teamShort, teamDesc, teamMembers) {
        this.teamName = teamName;
        this.teamShort = teamShort;
        this.teamDesc = teamDesc;
        this.teamMembers = teamMembers;
    }
    
    makeMemberList = async() =>
    {
        const members =  await (getallMembers());
        let memberObj;
        this.allMembers = members;
        this.allMembersDataList = document.createElement('datalist');
        this.allMembersDataList.id = 'members-list';
        for (memberObj of this.allMembers)
        {
            let option = document.createElement('option');
            option.value = memberObj.email;
            option.innerText = memberObj.name;
            option.id = memberObj.email;
            this.allMembersDataList.appendChild(option);
        }
        this.cardContainer.appendChild(this.allMembersDataList);
    }

    requestRender= async() =>
   { 
        team = JSON.parse(team);
        let tempArray = [];
        tempArray.push(team)
        renderTeamCards(tempArray);
        addTeam.hideForm();
    }
   
        renderTeamCards = async(event) =>
    {
        event.preventDefault();
        teams=await(fetchTeams());
        for (eachTeam of teams) {
            let newTeamCard = document.getElementById('new-team-card');
            let _id = eachTeam._id;
            let teamName = eachTeam.name;
            let shortName = eachTeam.shortName;
            let description = eachTeam.description;
            let membersEmails = [];
            let members = '';
            for (let teamObject = 0; teamObject < eachTeam.members.length; teamObject++) {
                 membersEmails.push(eachTeam.members[teamObject].email);
                if (teamObject == eachTeam.members.length - 1)
                    members += (eachTeam.members[teamObject].email + '\n');
                else
                    members += (eachTeam.members[teamObject].email + ',\n');
            }
            let cardTemplate = `
        <div class="team-about">
            <h2>${teamName}</h3>
            <h3>@${shortName}</h3>
            <div class="team-desc">${description}</div>
            <button id=excuse-${_id} class="excuse" onclick="excuseFromTeam(event)">Excuse Yourself</button>
        </div>

        <div class="team-mems">
            <span class="member-head">Members:</span><span id=span-${_id} class="members-span">${members}</span>
            <div class="team-select">
                <input id=members-${_id} list="members-list" name="team-members">
                <button id=button-${_id} class="add-to-team" onclick="addMemberToTeam(event)">Add</button>
            </div>
            <div id=error-${_id} class="team-form-help"></div>
        </div>
        `;
            let card = document.createElement('div');
            card.className = 'card';
            card.id = _id;
            card.membersArray = membersEmails;
            card.innerHTML = cardTemplate;
            this.cardContainer.insertBefore(card, newTeamCard);
            
        }
    }

    updateCard= async() =>
    {
        let teamObj;
        let teamID = event.target.id.split('-')[1];
        let teamCard = document.getElementById(teamID);
        let memberEmail = document.getElementById("members-" + teamID).value;
        if (memberEmail === '')
            return;
        for (teamObj of teamCard.membersArray)
        {
            if (teamObj === memberEmail)
            {   
                displayError('#error-${teamID}', '* Member ${memberEmail} already exists');
                return;
            }
            else
            {
                displayError('#error-${teamID}', '');
            }
        }
        await addMemberToTeam(teamID,memberEmail);
        if (memberEmail !== '')
        {
            document.getElementById(teamID).membersArray.push(memberEmail);
            let span = document.getElementById(`span-${teamID}`);
            span.innerText += `\n${memberEmail}`;
        }
    }

    removeCard = async() =>
    {
        let teamID = event.target.id.split('-')[1];
        await excuseFromTeam(teamID);
        let removed = document.getElementById(teamID);
        console.log(removed);
        this.cardContainer.removeChild(removed);
    }
   
       





    

}
export default team;
