import { displayError } from '../../js/utils/error-function.js';
class team {
    constructor(teamName, teamShort, teamDesc, teamMembers) {
        this.teamName = teamName;
        this.teamShort = teamShort;
        this.teamDesc = teamDesc;
        this.teamMembers = teamMembers;
    }
    fetchTeams() {

        makeAjaxRequest({ method: 'GET', endpoint: 'teams', authenticated: true })
            .then(result => renderTeamCards(JSON.parse(result)))
            .catch(error => console.log('error', error));

    }
    getAllMembers() {
        makeAjaxRequest({ method: 'GET', endpoint: 'teams', authenticated: true })
            .then(response => response.text())
            .then(result => makeMemberList(result))
            .catch(error => console.log('Error while getting members list', error));

    }

    requestRender(team) {

        team = JSON.parse(team);
        let tempArray = [];
        tempArray.push(team)
        renderTeamCards(tempArray);
        hideForm();
    }
    makeMemberList(members) {

        let allMembers = JSON.parse(members);
        let allMembersDataList = document.createElement('datalist');
        allMembersDataList.id = 'members-list';
        for (memberObj of allMembers) {
            let option = document.createElement('option');
            option.value = memberObj.email;
            option.innerText = memberObj.name;
            option.id = memberObj.email;
            allMembersDataList.appendChild(option);
        }
        cardContainer.appendChild(allMembersDataList);
    }


    renderTeamCards(teams) {

        for (eachTeam of teams) {
            let newTeamCard = document.getElementById('new-team-card');
            let _id = eachTeam._id;
            let teamName = eachTeam.name;
            let shortName = eachTeam.shortName;
            let description = eachTeam.description;
            let membersEmails = [];
            let members = '';
            for (let y = 0; y < eachTeam.members.length; y++) {
                membersEmails.push(eachTeam.members[y].email);
                if (y == eachTeam.members.length - 1)
                    members += (eachTeam.members[y].email + '\n');
                else
                    members += (eachTeam.members[y].email + ',\n');
            }
            let cardTemplate = `
        <div class="team-about">
            <h2>${teamName}</h3>
            <h3>@${shortName}</h3>
            <div class="team-desc">${description}</div>
            <button id=excuse-${_id} class="excuse" onclick="excuseFromTeam(event)">Excuse Yourself</button>
        </div>

        <div class="team-mems">
            <span class="member-head">Members:</span><span id=span-${_id} class="members-span">${members}</span>
            <div class="team-select">
                <input id=members-${_id} list="members-list" name="team-members">
                <button id=button-${_id} class="add-to-team" onclick="addMemberToTeam(event)">Add</button>
            </div>
            <div id=error-${_id} class="team-form-help"></div>
        </div>
        `;
            let card = document.createElement('div');
            card.className = 'card';
            card.id = _id;
            card.membersArray = membersEmails;
            card.innerHTML = cardTemplate;
            cardContainer.insertBefore(card, newTeamCard);
        }
    }
    updateCard(teamID, memberEmail) {

        if (memberEmail !== '') {
            document.getElementById(teamID).membersArray.push(memberEmail);
            let span = document.getElementById(`span-${teamID}`);
            span.innerText += `\n${memberEmail}`;
        }
    }

    removeCard(teamID) {

        let removed = document.getElementById(teamID);
        cardContainer.removeChild(removed);
    }
    addMemberToTeam(event) {
        let teamID = event.target.id.split('-')[1]
        let teamCard = document.getElementById(teamID);
        let memberEmail = document.getElementById("members-" + teamID).value;
        //let errorElement = document.getElementById(`error-${teamID}`);

        if (memberEmail === '')
            return;

        for (email of teamCard.membersArray) {
            if (email === memberEmail) {
                //errorElement.innerText = `* Member ${memberEmail} already exists`;
                displayError('#error-${teamID}', '* Member ${memberEmail} already exists');
                return;
            }
            else {
                //errorElement.innerText = '';
                displayError('#error-${teamID}', '');
            }
        }
        makeAjaxRequest({ method: 'PATCH', endpoint: 'teams/${teamID}?action=add_member&email=${memberEmail}', authenticated: true })

            .then(response => response.text())
            .then(updateCard(teamID, memberEmail))
            .catch(error => console.log('Failed to Add Member to the Team', error));

    }





    excuseFromTeam(event) {
        let teamID = event.target.id.split('-')[1]

        makeAjaxRequest({ method: 'PATCH', endpoint: 'teams/${teamID}?action=remove_member', authenticated: true })
            .then(response => response.text())
            .then(removeCard(teamID))
            .catch(error => console.log('Failed to Add Member', error));

    }

}
export default team;
